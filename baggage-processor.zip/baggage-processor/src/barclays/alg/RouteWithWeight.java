/**
 * <Copyright>
 */
package barclays.alg;

import java.util.Collections;
import java.util.List;

/**
 * 
 * @author samit
 *
 */
public class RouteWithWeight {
	private final List<String> nodes;
	private final int weight;
	
	/**
	 * 
	 * @param nodes
	 * @param weight
	 */
	public RouteWithWeight(List<String> nodes, int weight) {
		this.nodes = nodes;
		this.weight = weight;
	}

	/**
	 * @return the weight
	 */
	public int getWeight() {
		return weight;
	}

	/**
	 * @return the nodes
	 */
	public List<String> getNodes() {
		return Collections.unmodifiableList(nodes);
	}
	
	@Override
	public String toString(){
		return nodes.toString() + " : " + getWeight();
	}
}
