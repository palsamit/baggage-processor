/**
 * <Copyright>
 */
package barclays.alg;

/**
 * @author samit
 * Represents an uni-directional edge between two nodes
 */
public class DirectedConveyorSystemEdge extends ConveyorSystemEdge{
	/**
	 * @param start
	 * @param end
	 * @param weight
	 */
	public DirectedConveyorSystemEdge(String start, String end, int weight) {
		super(start, end, weight, false );
	}
}
