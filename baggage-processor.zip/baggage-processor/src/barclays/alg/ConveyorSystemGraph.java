/**
 * <Copyright>
 */
package barclays.alg;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

class ConveyorSystemGraph {
	Map<String, ConveyorSystemNode> nodes = new HashMap<String, ConveyorSystemNode>();

	public ConveyorSystemNode getNode(String nodeName) {
		return nodes.get(nodeName);
	}

	public void addNode(ConveyorSystemNode gNode) {
		nodes.put(gNode.getName(), gNode);
	}

	public Collection<ConveyorSystemNode> listNodes() {
		return nodes.values();
	}
}
