/**
 * <Copyright>
 */

package barclays.alg;

import java.util.List;

/**
 * 
 * @author samit
 *
 */

public final class RouteFinder {
	
	/**
	 * Find route from source node to target node with the provided graph
	 * @param source
	 * @param target
	 * @param edges
	 * @return
	 */
	public static RouteWithWeight findRoute(String source, String target, List<ConveyorSystemEdge> edges){
		return ShortestRouteFinder.findRoute(source, target, buildGraph(edges));
	}
	
	private static ConveyorSystemGraph buildGraph(List<ConveyorSystemEdge> edges) {
		ConveyorSystemGraph graph = new ConveyorSystemGraph();
		for( ConveyorSystemEdge edge: edges ) {
			ConveyorSystemNode gNode = graph.getNode(edge.getStart());
			if(gNode == null ) gNode = new ConveyorSystemNode(edge.getStart());
			gNode.addEdge(new DirectedConveyorSystemEdge(edge.getStart(), edge.getEnd(), edge.getWeight()));
			graph.addNode(gNode);
			
			if( edge.isBiderctional()) {
				gNode = graph.getNode(edge.getEnd());
				if(gNode == null ) gNode = new ConveyorSystemNode(edge.getEnd());
				DirectedConveyorSystemEdge reverseEdge = new DirectedConveyorSystemEdge(edge.getEnd(), edge.getStart(), edge.getWeight());
				gNode.addEdge(reverseEdge);
				graph.addNode(gNode);
			}
		}
		return graph;
	}
	//TBD
	// Any other findRoute implementation, algorithm, ...
	//
}
