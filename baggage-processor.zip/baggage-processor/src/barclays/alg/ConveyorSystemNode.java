/**
 * <Copyright>
 */
package barclays.alg;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

class ConveyorSystemNode {
	final String nodeName;
	Set<DirectedConveyorSystemEdge> edges = new HashSet<DirectedConveyorSystemEdge>();

	public ConveyorSystemNode(String nodeName) {
		this.nodeName = nodeName;
	}

	public void addEdge(DirectedConveyorSystemEdge edge) {
		edges.add(edge);
	}

	public String getName() {
		return nodeName;
	}

	public Collection<DirectedConveyorSystemEdge> listEdges() {
		return edges;
	}
}
