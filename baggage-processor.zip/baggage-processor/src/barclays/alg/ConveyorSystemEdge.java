/**
 * <Copyright>
 */
package barclays.alg;

/**
 * @author samit
 * An edge between two nodes
 */
public class ConveyorSystemEdge {
	private boolean bidirectional = true; 
	private final String start;
	private final String end;
	private final int weight;
	
	/**
	 * @param start
	 * @param end
	 * @param weight
	 */
	public ConveyorSystemEdge(String start, String end, int weight) {
		this.start = start;
		this.end = end;
		this.weight = weight;
	}

	/**
	 * @param start
	 * @param end
	 * @param weight
	 * @param birectional
	 */
	public ConveyorSystemEdge(String start, String end, int weight, boolean birectional) {
		this.start = start;
		this.end = end;
		this.weight = weight;
		this.bidirectional = birectional;
	}

	/**
	 * @return the weight
	 */
	public int getWeight() {
		return weight;
	}

	/**
	 * @return the end
	 */
	public String getEnd() {
		return end;
	}

	/**
	 * @return the start
	 */
	public String getStart() {
		return start;
	}

	/**
	 * @return if unidirectional or bidirectional edge
	 */
	public boolean isBiderctional() {
		return bidirectional ;
	}
	
	@Override
	public String toString(){
		return start + "--("+weight+ ")--" + end ;
	}
}
