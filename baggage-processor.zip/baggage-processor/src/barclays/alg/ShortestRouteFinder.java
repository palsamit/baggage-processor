/**
 * <Copyright>
 */
package barclays.alg;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;

/**
 * 
 * @author samit
 *
 */
class ShortestRouteFinder {	
	/**
	 * Find shortest route from source node to target node from the given edges
	 * @param source
	 * @param target
	 * @param graph 
	 * @return shortest route with weight 
	 */
	public static RouteWithWeight findRoute(String source, String target, ConveyorSystemGraph graph){
		Map<String, String> previousNodeMap = new HashMap<String, String>();		// Previous node of the key node in the shortest route
		Map<String, Integer> shortestDistanceMap = initShortestDistanceMap(graph);	// Shortest distance to the key node from source
		Set<String> visitedNodes = new HashSet<String>();							// Visited node list to avoid loop
				
		if( !shortestDistanceMap.containsKey(source)) throw new IllegalArgumentException("inavalid source node name:" + source);
		if( !shortestDistanceMap.containsKey(target)) throw new IllegalArgumentException("inavalid destination node name:" + target);
		
		shortestDistanceMap.put(source, 0);									// set 0 for the source node
		
		Queue<String> pendingQueue = createPriorityQueue(shortestDistanceMap);	// Maintains list of pending nodes ordered by shortest distance so far
		
		pendingQueue.add(source);											// set source as the first entry to check
		while( !pendingQueue.isEmpty() ) {			
			ConveyorSystemNode currentNode = graph.getNode(pendingQueue.poll());
			if( currentNode == null ) continue;								// invalid node ( source or destination )
			visitedNodes.add(currentNode.getName());
			
			visitAdjacentNodes(currentNode, graph, previousNodeMap
						, shortestDistanceMap, visitedNodes,pendingQueue );			
		}
		
		if( !shortestDistanceMap.containsKey(target)) return null;
		
		List<String> route = extractRoute(previousNodeMap, target);		// extract route using previous node map
		
		return new RouteWithWeight(route, shortestDistanceMap.get(target));
	}

	private static void visitAdjacentNodes(ConveyorSystemNode currentNode
										, ConveyorSystemGraph graph
										, Map<String, String> previousNodeMap
										, Map<String, Integer> shortestDistanceMap
										, Set<String> visitedNodes
										, Queue<String> pendingQueue) {
		for( DirectedConveyorSystemEdge dEdge : currentNode.listEdges()){						// for all adjacent node from currentNode process..
			if(visitedNodes.contains(dEdge.getEnd())) continue;					// if adjacent node already visited, continue
			
			ConveyorSystemNode adjacentNode = graph.getNode(dEdge.getEnd());				// Get next adjacent node
			if( shortestDistanceMap.get(adjacentNode.getName())					// previously calculated distance greater
					> (shortestDistanceMap.get(currentNode.getName())
						+ dEdge.getWeight()	))	{								// than current route,
				
				updateShortestDistanceOnAdjancentNode(currentNode, adjacentNode
						, dEdge, previousNodeMap, shortestDistanceMap, pendingQueue);
				
			}
		}
	}

	private static void updateShortestDistanceOnAdjancentNode(
					ConveyorSystemNode currentNode
					, ConveyorSystemNode adjacentNode
					, DirectedConveyorSystemEdge dEdge
					, Map<String, String> previousNodeMap
					, Map<String, Integer> shortestDistanceMap
					, Queue<String> pendingQueue) {
		shortestDistanceMap.put(adjacentNode.getName()
				, shortestDistanceMap.get(currentNode.getName())
				+ dEdge.getWeight());									// update shortest distance
		previousNodeMap.put(adjacentNode.getName(), currentNode.getName());		// set current node as the previous node of the adjacent node
		pendingQueue.add(adjacentNode.getName());						// add adjacent node for further processing
	}

	private static Queue<String> createPriorityQueue(Map<String, Integer> shortestDistanceMap) {
		Queue<String> priorityQueue = new PriorityQueue<String>(shortestDistanceMap.size(), new Comparator<String>(){
			@Override
			public int compare(String node1, String node2) {
				return shortestDistanceMap.get(node1) - shortestDistanceMap.get(node2);
			}
		});
		return priorityQueue;
	}

	private static Map<String, Integer> initShortestDistanceMap(ConveyorSystemGraph graph) {
		Map<String, Integer> shortestDistanceMap = new HashMap<String, Integer>();	// Shortest distance to the key node from source
		for(ConveyorSystemNode gNode: graph.listNodes() ) {
			shortestDistanceMap.put(gNode.getName(), Integer.MAX_VALUE);			// set max value for every node			
		}
		return shortestDistanceMap;
	}
	
	
	private static List<String> extractRoute(Map<String, String> previousNodeMap, String destinationNode) {
		LinkedList<String> route = new LinkedList<String>();		
		String prevNode = destinationNode; 
		route.push(prevNode);
		do {
			prevNode = previousNodeMap.get(prevNode);
			if( prevNode != null )  route.push(prevNode);
		} while( prevNode != null && !prevNode.equals(destinationNode) ) ;
		return route;
	}	
}
