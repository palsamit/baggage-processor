/**
 * <Copyright>
 */
package barclays.airport.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import barclays.airport.BaggageProcessor;
import barclays.airport.BaggageRoute;
import barclays.airport.dao.BaggageInfo;
import barclays.airport.dao.DepartureInfo;
import barclays.airport.dao.FlightDao;

/**
 * Processes command line input for this design challenge and displays output on the command line
 * <p>Enter 3 section of data then end input by entering # as the last line.
 * <p>For example,
 * <br>{@code # Section: Conveyor System}
 * <br>{@code <Node 1> <Node 2> <travel_time>}
 * <br>{@code ...  }
 * <br>{@code # Section: Departures}
 * <br>{@code <flight_id> <flight_gate> <destination> <flight_time>}
 * <br>{@code ...}
 * <br>{@code # Section: Bags}
 * <br>{@code <bag_number> <entry_point> <flight_id>}
 * <br>{@code ...}
 * <br>{@code #}
 * @author samit
 */
public class CmdLineProcessor {
	
	/**
	 * @param args
	 */
	public static void main(String args[]){
		BaggageProcessor baggageProcessor = new BaggageProcessor("Denver");
		Scanner scanner = new Scanner(System.in);
		
		readInputAndInitializeBaggageProcessor(scanner, baggageProcessor);
		
		List<BaggageInfo> baggages = readBags(scanner);
				
		scanner.close();		
		// End of reading input
		for( BaggageInfo bagInfo: baggages) {
			findAndPrintOptimizedRoute(baggageProcessor, bagInfo);
		}
	}

	
	private static List<BaggageInfo> readBags(Scanner scanner) {
		List<BaggageInfo> baggages = new ArrayList<BaggageInfo>();
		//# Section: Bags
		//<bag_number> <entry_point> <flight_id>
		String line = null;
		while(scanner.hasNextLine() && !(line = scanner.nextLine()).startsWith("#")){
			BaggageInfo bagInfo = parseBag(line);
			if( bagInfo != null ) baggages.add(bagInfo);			
		}
		return baggages;
	}


	private static void readInputAndInitializeBaggageProcessor(Scanner scanner, BaggageProcessor baggageProcessor) {
		
		//# Section: Conveyor System
		//Format: <Node 1> <Node 2> <travel_time>
		String line = null;
		
		while(scanner.hasNextLine() && !(line = scanner.nextLine()).startsWith("#"));

		while(scanner.hasNextLine() && !(line = scanner.nextLine()).startsWith("#")){			
			parseAndAddConveyorSystem(baggageProcessor, line);
		}
		
		//# Section: Departures
		//<flight_id> <flight_gate> <destination> <flight_time>
		while(scanner.hasNextLine() && !(line = scanner.nextLine()).startsWith("#")){
			parseAndSaveFlightDepartures(line);
		}
		
	}


	private static void findAndPrintOptimizedRoute(BaggageProcessor baggageProcessor, BaggageInfo bagInfo) {
		System.out.print(bagInfo.getBagNumber() + " ");
		BaggageRoute baggageRoute = baggageProcessor.findRoute(bagInfo);
		if(baggageRoute == null ) System.out.println("No route found");
		else {
			for( String node: baggageRoute.getNodes()) {
				System.out.print(node + " ");
			}
			System.out.println(": " + baggageRoute.getTravelTime());
		}
	}

	private static BaggageInfo parseBag(String line) {
		BaggageInfo bagInfo = null;
		Pattern p = Pattern.compile("(\\w+)\\s+(\\w+)\\s+(\\w+)");
		Matcher m = p.matcher(line);
		if( m.matches() ) {
			bagInfo = new BaggageInfo();
			bagInfo.setBagNumber(m.group(1));
			bagInfo.setEntryPoint(m.group(2));
			bagInfo.setFlightId(m.group(3));
		} else {
			System.out.println("Invalid bag input in line:" + line);
		}
		return bagInfo;
	}

	private static void parseAndSaveFlightDepartures(String line) {
		Pattern p = Pattern.compile("(\\w+)\\s+(\\w+)\\s+(\\w+)\\s+(\\S+)");
		Matcher m = p.matcher(line);
		if( m.matches() ) {
			FlightDao.saveFlightDepartureInfo(new DepartureInfo(m.group(1), m.group(2)));
		} else {
			System.out.println("Invalid departure input in line:" + line);
		}	
	}

	private static void parseAndAddConveyorSystem(BaggageProcessor baggageProcessor, String line) {
		Pattern p = Pattern.compile("(\\w+)\\s+(\\w+)\\s+(\\d+)");
		Matcher m = p.matcher(line);
		if( m.matches() ) {
			try{
				baggageProcessor.addConveyorBelt(m.group(1), m.group(2), Integer.parseInt(m.group(3)));
			} catch(Exception e) {
				System.out.println("Invalid Conveyor input in line:" + line);
			}
		} else {
			System.out.println("Invalid Conveyor input in line:" + line);
		}		
	}
}