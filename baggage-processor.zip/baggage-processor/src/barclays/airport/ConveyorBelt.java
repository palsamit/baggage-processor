/**
 * <Copyright>
 */
package barclays.airport;

import barclays.alg.ConveyorSystemEdge;
import barclays.util.StringUtil;

/**
 * 
 * @author samit
 *
 */
class ConveyorBelt {
	private ConveyorSystemEdge edge;
	
	private boolean active = true;
	
	/**
	 * 
	 * @param startingGate
	 * @param endingGate
	 * @param travelTime
	 */
	public ConveyorBelt(String startingGate, String endingGate, int travelTime ) {
		if( StringUtil.isEmptyOrNull(startingGate)) {
			throw new IllegalArgumentException("invalid start name");
		}
		
		if( StringUtil.isEmptyOrNull(endingGate)) {
			throw new IllegalArgumentException("invalid end name");
		}
		
		if( travelTime <= 0 ) {
			throw new IllegalArgumentException("invalid travel time");
		}

		edge = new ConveyorSystemEdge(startingGate, endingGate, travelTime);
	}

	/**
	 * 
	 * @return
	 */
	ConveyorSystemEdge getEdge() {
		return edge;
	}


	/**
	 * block this conveyor belt
	 */
	void block(){
		setActive(false);
	}
	
	/**
	 * bring this belt to service
	 */
	void activate(){
		setActive(true);
	}
	
	/**
	 * change travel time if required
	 * @param newTravelTime
	 */
	void changeTravelTime( int newTravelTime ) {
		edge = new ConveyorSystemEdge(edge.getStart(), edge.getEnd(), newTravelTime);
	}

	/**
	 * @return the active
	 */
	boolean isActive() {
		return active;
	}

	/**
	 * @param active the active to set
	 */
	void setActive(boolean active) {
		this.active = active;
	}
	
	/**
	 * @return true if start & end names matches. weight is not considered for equality.
	 *  
	 * 
	 */
	@Override
	public boolean equals(Object obj){
		if( !(obj instanceof ConveyorBelt)) return false;
		ConveyorBelt otherBelt = (ConveyorBelt)obj;
		if( this.edge.getStart().equals(otherBelt.edge.getStart())
				&& this.edge.getEnd().equals(otherBelt.edge.getEnd())) {
			return true;
		}
		
		return false;
	}
	
	@Override
	public int hashCode(){
		return 31*edge.getStart().hashCode() + edge.getEnd().hashCode();
	}
	
	@Override
	public String toString(){
		return edge.toString() + "("+active+")";
	}
}
