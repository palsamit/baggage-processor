/**
 * <Copyright>
 */
package barclays.airport;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import barclays.alg.*;

/**
 * @author samit
 *
 */
final class BaggageRouter {
	
	private final Set<ConveyorBelt> conveyorBelts
			= Collections.newSetFromMap(new ConcurrentHashMap<ConveyorBelt, Boolean>());	// List of conveyor belts for this airport
	
	private final Map<TerminalPair, BaggageRoute> routeMap
			= new ConcurrentHashMap<TerminalPair, BaggageRoute>();						// Cache to hold routes that are already found
	
	/**
	 * A pair of 2 ends
	 * @author samit
	 *
	 */
	private static class TerminalPair{
		private final String terminal1;
		private final String terminal2;
		
		public TerminalPair(String terminal1, String terminal2) {
			this.terminal1 = terminal1;
			this.terminal2 = terminal2;
		}

		@Override
		public boolean equals(Object obj){
			if( !(obj instanceof TerminalPair)) return false;
			TerminalPair otherTerminalPair = (TerminalPair)obj;
			if( this.terminal1.equals(otherTerminalPair.terminal1)
					&& this.terminal2.equals(otherTerminalPair.terminal2)) {
				return true;
			}
			
			return false;
		}
		
		/**
		 * 
		 */
		@Override
		public int hashCode(){
			return 31*terminal1.hashCode() + terminal1.hashCode();
		}
		
		@Override
		public String toString(){
			return "[" + terminal1 + "," + terminal2 + "]";
		}
	}
	
	public void addConveyorBelt(ConveyorBelt conveyorBelt){
		conveyorBelts.add(conveyorBelt);
	}
	
	/**
	 * Finds baggage route from source to target.
	 * @param source
	 * @param target
	 * @return	returns {@link BaggageRoute} if a route found between the two end or null if no route found
	 */
	public BaggageRoute findRoute(String source, String target){
		TerminalPair termPair = new TerminalPair(source, target);
		if(routeMap.containsKey(termPair)) {
			//System.out.println("Using Cached Value for " + termPair );
			return routeMap.get(termPair);		// If found, return from Cache 
		}
		
		List<ConveyorSystemEdge> activeEdges = conveyorBelts.stream()
									.filter(conveyorBelt -> conveyorBelt.isActive())
									.map(ConveyorBelt::getEdge)
									.collect(Collectors.toList());				// Filter active belts
		
		RouteWithWeight routeWithWeight = RouteFinder.findRoute(source, target, activeEdges);	// find route
		if( routeWithWeight != null ) {
			BaggageRoute route = new BaggageRoute(routeWithWeight);
			routeMap.put(termPair, route);										// add to  cache
			return route;
		} else {
			//routeMap.put(termPair, null);										// add null to cache to prevent finding route if it doesn't exist
		}
		return null;
		
	}

	@Override
	public String toString(){
		return conveyorBelts.size() + " Conveyor belts configured";
	}

	/**
	 * 
	 * @param beltSource
	 * @param beltDestination
	 */
	public void blockConveyorBelt(String beltSource, String beltDestination) {
		ConveyorBelt compareBelt = new ConveyorBelt(beltSource, beltDestination, 1);
		ConveyorBelt reverseBelt = new ConveyorBelt(beltDestination, beltSource, 1);
		conveyorBelts.stream()
			.filter(e -> e.equals(compareBelt) || e.equals(reverseBelt) )
			.forEach(e -> e.block());		// block entries matching this belt( should be only 1 entry max)
		
		routeMap.clear();					// Clear cache, to rebuild route
	}

	/**
	 * 
	 * @param beltSource
	 * @param beltDestination
	 */
	public void activateConveyorBelt(String beltSource, String beltDestination) {
		ConveyorBelt compareBelt = new ConveyorBelt(beltSource, beltDestination, 1);
		ConveyorBelt reverseBelt = new ConveyorBelt(beltDestination, beltSource, 1);
		conveyorBelts.stream()
			.filter(e -> e.equals(compareBelt)  || e.equals(reverseBelt) )
			.forEach(e -> e.activate());		// activate entries matching this belt( should be only 1 entry max)
		routeMap.clear();						// Clear cache, to rebuild route
	}
	
	/**
	 * 
	 * @param sourceOrDestinationName
	 */
	public void blockConveyorBeltFromOrTo(String sourceOrDestinationName) {
		conveyorBelts.stream()
			.filter(e -> e.getEdge().getStart().equals(sourceOrDestinationName) || e.getEdge().getEnd().equals(sourceOrDestinationName))
			.forEach(e -> e.block());		// block entries matching this belt's source/destination name
		routeMap.clear();					// Clear cache, to rebuild route
	}

	/**
	 * 
	 * @param sourceOrDestinationName
	 */
	public void activateConveyorBeltFromOrTo(String sourceOrDestinationName) {
		conveyorBelts.stream()
			.filter(e -> e.getEdge().getStart().equals(sourceOrDestinationName) || e.getEdge().getEnd().equals(sourceOrDestinationName))
			.forEach(e -> e.activate());		// activate entries matching this belt's source/destination name
		routeMap.clear();						// Clear cache, to rebuild route
	}

	public void removeConveyorBelt(ConveyorBelt conveyorBelt) {
		conveyorBelts.remove(conveyorBelt);
	}
}
