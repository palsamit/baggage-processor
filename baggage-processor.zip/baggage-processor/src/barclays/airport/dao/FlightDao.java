/**
 * <Copyright>
 */
package barclays.airport.dao;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author samit
 * Ideally Departure information should be coming for external datastore, this class acts as temp store for the input data
 */
public class FlightDao {
	private static Map<String, DepartureInfo> departureInfoDB = new ConcurrentHashMap<String, DepartureInfo>();		// <flightId,DepartureInfo>
	
	/**
	 * @param flightId
	 * @return	returns departure info based on flightId
	 */
	public static DepartureInfo getFlightDepartureInfo( String flightId){
		return departureInfoDB.get(flightId);
	}
	
	/**
	 * @param departureInfo
	 */
	public static void saveFlightDepartureInfo( DepartureInfo departureInfo){
		departureInfoDB.put(departureInfo.getFlightId(), departureInfo );
	}
	
	/**
	 * 
	 * @param departureInfo
	 */
	public static void deleteFlightDepartureInfo( DepartureInfo departureInfo){
		if( departureInfoDB.containsKey(departureInfo.getFlightId())) {
			departureInfoDB.remove(departureInfo.getFlightId());
		}
	}

	/**
	 * 
	 * @return number of departure info
	 */
	public static int getNoOfDepartureInfo() {
		return departureInfoDB.size();
	}
	
}
