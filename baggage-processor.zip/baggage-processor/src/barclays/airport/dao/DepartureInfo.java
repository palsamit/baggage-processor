/**
 * <Copyright>
 */
package barclays.airport.dao;

/**
 * @author samit
 *
 */
public class DepartureInfo {
	private String flightId;
	private String flightGate;
	//String destination;		// field ignored currently
	//String flight_time;		// field ignored currently
	
	
	/**
	 * @param flightId
	 * @param flightGate
	 */
	public DepartureInfo(String flightId, String flightGate){
		this.flightId = flightId;
		this.flightGate = flightGate;		
	}
	
	/**
	 * @return the flightId
	 */
	public String getFlightId() {
		return flightId;
	}
	/**
	 * @param flightId the flightId to set
	 */
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}
	/**
	 * @return the flightGate
	 */
	public String getFlightGate() {
		return flightGate;
	}
	/**
	 * @param flightGate the flightGate to set
	 */
	public void setFlightGate(String flightGate) {
		this.flightGate = flightGate;
	}
	
	@Override
	public String toString(){
		return "Id:" + this.getFlightId() + ", gate:" + this.getFlightGate();
	}
}
