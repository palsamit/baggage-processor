/**
 * <Copyright>
 */

package barclays.airport.dao;

/**
 * 
 * @author samit
 *
 */
public class BaggageInfo {
	private String bagNumber;
	private String entryPoint;
	private String flightId;
	
	/**
	 * @return the bagNumber
	 */
	public String getBagNumber() {
		return bagNumber;
	}
	
	/**
	 * @param bagNumber the bagNumber to set
	 */
	public void setBagNumber(String bagNumber) {
		this.bagNumber = bagNumber;
	}
	
	/**
	 * @return the entryPoint
	 */
	public String getEntryPoint() {
		return entryPoint;
	}
	
	/**
	 * @param entryPoint the entryPoint to set
	 */
	public void setEntryPoint(String entryPoint) {
		this.entryPoint = entryPoint;
	}
	
	/**
	 * @return the flightId
	 */
	public String getFlightId() {
		return flightId;
	}
	
	/**
	 * @param flightId the flightId to set
	 */
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}
	
	/**
	 * 
	 */
	@Override
	public String toString(){
		return "bagNo" + this.getBagNumber() + ", entered:" + this.getEntryPoint() + ", flightId:" + this.getFlightId();
	}
}
