/**
 * <Copyright>
 */
package barclays.airport;

import java.util.List;

import barclays.alg.RouteWithWeight;

/**
 * Provides a list of nodes representing baggage route
 * 
 * @author samit
 *
 */
public class BaggageRoute {
	final RouteWithWeight routeWithWeight;
	
	BaggageRoute(RouteWithWeight routeWithWeight){
		this.routeWithWeight = routeWithWeight;
	}
	
	/**
	 * @return the travel time for this route
	 */
	public int getTravelTime() {
		return routeWithWeight.getWeight();
	}

	/**
	 * @return the nodes in order from source to destination
	 */
	public List<String> getNodes() {
		return routeWithWeight.getNodes();
	}
	
	@Override
	public String toString(){
		return routeWithWeight.toString();
	}
}
