/**
 * <Copyright>
 */
package barclays.airport;

import barclays.airport.dao.BaggageInfo;
import barclays.airport.dao.DepartureInfo;
import barclays.airport.dao.FlightDao;
import barclays.util.StringUtil;

/**
 * 
 * Use BaggageProcessor class create and maintain a baggage processing system for any airport.
 *<p>
 *{@code	BaggageProcessor baggageProcessor = new BaggageProcessor("Denver"); }
 *<p>
 * Then add/remove conveyer belts to this airport.
 * <br>{@code baggageProcessor.addConveyorBelt("Concourse_A_Ticketing", "A5", 5);}
 * <br>{@code baggageProcessor.addConveyorBelt("A5", "BaggageClaim", 5);}
 * <br>{@code ...}
 * <p>
 * To find a route for a given baggage call findRoute
 * <br>{@code BaggageRoute route = baggageProcessor.findRoute(baggageInfo);}	
 *
 * @author samit
 */
public class BaggageProcessor {
	private final String airportName;																	// Airport name
	private final BaggageRouter baggageRouter = new BaggageRouter();
	
	/**
	 * 
	 * @param airportName
	 */
	public BaggageProcessor(String airportName){
		if( StringUtil.isEmptyOrNull(airportName)) {
			throw new IllegalArgumentException("invalid airport name");
		}
		this.airportName = airportName;
	}


	/**
	 * @return the airport name
	 */
	public String getAirportName() {
		return airportName;
	}
	
	/**
	 * Add a conveyor for this baggage processor
	 * @param source
	 * @param target
	 * @param travelTime
	 */
	public void addConveyorBelt(String source, String target, int travelTime){
		baggageRouter.addConveyorBelt(new ConveyorBelt(source, target, travelTime));
	}

	/**
	 * 
	 * @param source
	 * @param target
	 */
	public void removeConveyorBelt(String source, String target) {		
		baggageRouter.removeConveyorBelt(new ConveyorBelt(source, target, 1));	// traveltime is ignored in comparison
	}

	/**
	 * Find the shortest route for a baggage 
	 * @param bagInfo
	 * @return	returns the shortest route for this baggage.
	 * 			throws IllegalArgumentException if invalid or incorrect information is provided
	 */
	public BaggageRoute findRoute(BaggageInfo bagInfo) {
		if(bagInfo == null
				|| StringUtil.isEmptyOrNull(bagInfo.getBagNumber())
				|| StringUtil.isEmptyOrNull(bagInfo.getEntryPoint())
				|| StringUtil.isEmptyOrNull(bagInfo.getFlightId())) {
			throw new IllegalArgumentException("invalid bagInfo");
		}
		String target="BaggageClaim";
		if("ARRIVAL".equals(bagInfo.getFlightId())) {
		} else {
			DepartureInfo depInfo = FlightDao.getFlightDepartureInfo(bagInfo.getFlightId());
			if( depInfo == null ) {
				throw new IllegalArgumentException("no matching gate/departure info found for bag:" + bagInfo );
			}
			target = depInfo.getFlightGate();
		}
		return findRoute(bagInfo.getEntryPoint(), target);
	}
	
	/**
	 * Finds baggage route from source to target.
	 * @param source
	 * @param target
	 * @return	returns {@link BaggageRoute} if a route found between the two end or null if no route found
	 */
	public BaggageRoute findRoute(String source, String target) {
		if(StringUtil.isEmptyOrNull(source)) {
			throw new IllegalArgumentException("invalid source node");
		}
		
		if(StringUtil.isEmptyOrNull(target)) {
			throw new IllegalArgumentException("invalid target node");
		}
		
		return baggageRouter.findRoute(source, target);
	}
	
	
	/**
	 * Block conveyor belt identified by source and destination point/node
	 * @param beltSource
	 * @param beltDestination
	 */
	public void blockConveyorBelt(String beltSource, String beltDestination){
		baggageRouter.blockConveyorBelt(beltSource, beltDestination);
	}
	
	/**
	 * Activate conveyor belt identified by source and destination point/node
	 * @param beltSource
	 * @param beltDestination
	 */
	public void activateConveyorBelt(String beltSource, String beltDestination){
		baggageRouter.activateConveyorBelt(beltSource, beltDestination);
	}
	
	/**
	 * Block all conveyor belts from or to this point/node
	 * @param sourceOrDestinationName
	 */
	public void blockConveyorBeltFromOrTo(String sourceOrDestinationName) {
		baggageRouter.blockConveyorBeltFromOrTo(sourceOrDestinationName);
	}
	
	/**
	 * Activate all conveyor belts from or to this point/node
	 * @param sourceOrDestinationName
	 */
	public void activateConveyorBeltFromOrTo(String sourceOrDestinationName) {
		baggageRouter.activateConveyorBeltFromOrTo(sourceOrDestinationName);
	}
}
