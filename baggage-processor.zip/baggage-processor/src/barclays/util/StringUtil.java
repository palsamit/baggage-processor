/**
 * <Copyright>
 */
package barclays.util;

/**
 * Provides string related utility methods
 * @author samit
 *
 */
public class StringUtil {
	/**
	 * 
	 * @param str
	 * @return	return true if str is null or empty
	 */
	public static boolean isEmptyOrNull(String str){
		return str == null || str.isEmpty();
	}
}
