


Jar file is created in lib folder, compiled using 1.8.0_111

To integrate this library refer javadoc barclays.airport.BaggageProcessor


To run this program from command line. Enter the entire input text and end with # <Enter> 
java -jar baggageprocessor.jar


Or,
java -jar baggageprocessor.jar  < ../input/sampleinput1.txt

This  project is created in Eclipse neon.
