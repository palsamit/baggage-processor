package barclays.airport;

import org.junit.BeforeClass;
import org.junit.Test;

import barclays.airport.dao.BaggageInfo;
import barclays.airport.dao.DepartureInfo;
import barclays.airport.dao.FlightDao;
import org.junit.Assert;

@SuppressWarnings("javadoc")
public class TestBaggageProcessor {
	private static BaggageProcessor baggageProcessor = new BaggageProcessor("Denver");
	
	@BeforeClass
	public static void setup(){
		baggageProcessor.addConveyorBelt("Concourse_A_Ticketing", "A5", 5);
		baggageProcessor.addConveyorBelt("A5", "BaggageClaim", 5);
		baggageProcessor.addConveyorBelt("A5", "A10", 4);
		baggageProcessor.addConveyorBelt("A5", "A1", 6);
		baggageProcessor.addConveyorBelt("A1", "A2", 1);
		baggageProcessor.addConveyorBelt("A2", "A3", 1);
		baggageProcessor.addConveyorBelt("A3", "A4", 1);
		baggageProcessor.addConveyorBelt("A10", "A9", 1);
		baggageProcessor.addConveyorBelt("A9", "A8", 1);
		baggageProcessor.addConveyorBelt("A8", "A7", 1);
		baggageProcessor.addConveyorBelt("A7", "A6", 1);
		
		baggageProcessor.addConveyorBelt("A7", "A9", 2);
		
		
		FlightDao.saveFlightDepartureInfo(new DepartureInfo("UA10", "A1"));// MIA 08:00
		FlightDao.saveFlightDepartureInfo(new DepartureInfo("UA11", "A1"));//  LAX 09:00
		FlightDao.saveFlightDepartureInfo(new DepartureInfo("UA12", "A1"));//  JFK 09:45
		FlightDao.saveFlightDepartureInfo(new DepartureInfo("UA13", "A2"));//  JFK 08:30
		FlightDao.saveFlightDepartureInfo(new DepartureInfo("UA14", "A2"));//  JFK 09:45
		FlightDao.saveFlightDepartureInfo(new DepartureInfo("UA15", "A2"));//  JFK 10:00
		FlightDao.saveFlightDepartureInfo(new DepartureInfo("UA16", "A3"));//  JFK 09:00
		FlightDao.saveFlightDepartureInfo(new DepartureInfo("UA17", "A4"));//  MHT 09:15
		FlightDao.saveFlightDepartureInfo(new DepartureInfo("UA18", "A5"));//  LAX 10:15
	}
	
	@Test
	public void testRoute1() {
		BaggageInfo baggageInfo = new BaggageInfo();
		baggageInfo.setBagNumber("0001");
		baggageInfo.setEntryPoint("Concourse_A_Ticketing");
		baggageInfo.setFlightId("UA12");
		BaggageRoute route = baggageProcessor.findRoute(baggageInfo);
		Assert.assertEquals(11, route.getTravelTime());
		Assert.assertArrayEquals(new String[]{"Concourse_A_Ticketing", "A5", "A1"}, route.getNodes().toArray());
	}
	@Test
	public void testRoute2() {
		BaggageInfo baggageInfo = new BaggageInfo();
		baggageInfo.setBagNumber("0002");
		baggageInfo.setEntryPoint("A5");
		baggageInfo.setFlightId("UA17");
		BaggageRoute route = baggageProcessor.findRoute(baggageInfo);
		Assert.assertEquals(9, route.getTravelTime());
		Assert.assertArrayEquals(new String[]{"A5", "A1", "A2", "A3", "A4"}, route.getNodes().toArray());
	}
	
	@Test
	public void testRoute3() {
		BaggageInfo baggageInfo = new BaggageInfo();
		baggageInfo.setBagNumber("0003");
		baggageInfo.setEntryPoint("A2");
		baggageInfo.setFlightId("UA10");
		BaggageRoute route = baggageProcessor.findRoute(baggageInfo);
		Assert.assertEquals(1, route.getTravelTime());
		Assert.assertArrayEquals(new String[]{"A2", "A1"}, route.getNodes().toArray());
	}
	
	@Test
	public void testRoute4() {
		BaggageInfo baggageInfo = new BaggageInfo();
		baggageInfo.setBagNumber("0004");
		baggageInfo.setEntryPoint("A8");
		baggageInfo.setFlightId("UA18");
		BaggageRoute route = baggageProcessor.findRoute(baggageInfo);
		Assert.assertEquals(6, route.getTravelTime());
		Assert.assertArrayEquals(new String[]{"A8", "A9", "A10", "A5"}, route.getNodes().toArray());
	}
	  
	@Test
	public void testRoute5() {
		BaggageInfo baggageInfo = new BaggageInfo();
		baggageInfo.setBagNumber("0005");
		baggageInfo.setEntryPoint("A7");
		baggageInfo.setFlightId("ARRIVAL");
		BaggageRoute route = baggageProcessor.findRoute(baggageInfo);
		Assert.assertEquals(12, route.getTravelTime());
		Assert.assertArrayEquals(new String[]{"A7", "A8", "A9", "A10", "A5", "BaggageClaim"}, route.getNodes().toArray());
	}

	@Test(expected=IllegalArgumentException.class)
	public void testNullBaggageInfo() {
		BaggageRoute route = baggageProcessor.findRoute(null);
		Assert.fail();
	}

	@Test(expected=IllegalArgumentException.class)
	public void testInvalidEntrypoint() {
		BaggageInfo baggageInfo = new BaggageInfo();
		baggageInfo.setBagNumber("0005");
		baggageInfo.setEntryPoint("A700");
		baggageInfo.setFlightId("ARRIVAL");
		BaggageRoute route = baggageProcessor.findRoute(baggageInfo);
		Assert.fail();
	}

	@Test(expected=IllegalArgumentException.class)
	public void testInvalidFlightId() {
		BaggageInfo baggageInfo = new BaggageInfo();
		baggageInfo.setBagNumber("0004");
		baggageInfo.setEntryPoint("A8");
		baggageInfo.setFlightId("UA180");
		BaggageRoute route = baggageProcessor.findRoute(baggageInfo);
		Assert.fail();
	}

	public void testByNodeNames() {
		BaggageRoute route = baggageProcessor.findRoute("A8", "A5");
		Assert.assertEquals(6, route.getTravelTime());
		Assert.assertArrayEquals(new String[]{"A8", "A9", "A10", "A5"}, route.getNodes().toArray());
	}

	@Test(expected=IllegalArgumentException.class)
	public void testInvalidSourceNode() {
		BaggageRoute route = baggageProcessor.findRoute("A80", "A5");
		Assert.fail();
	}

	@Test(expected=IllegalArgumentException.class)
	public void testInvalidDestinationNode() {
		BaggageRoute route = baggageProcessor.findRoute("A8", "A50");
		System.out.println(route);
		Assert.fail();
	}
	
	@Test
	public void testRouteBlock() {
		baggageProcessor.addConveyorBelt("A7", "A9", 2);
		
		BaggageInfo baggageInfo = new BaggageInfo();
		baggageInfo.setBagNumber("0005");
		baggageInfo.setEntryPoint("A7");
		baggageInfo.setFlightId("ARRIVAL");
		
		baggageProcessor.blockConveyorBelt("A7", "A8");
		BaggageRoute route = baggageProcessor.findRoute(baggageInfo);
		Assert.assertEquals(12, route.getTravelTime());
		Assert.assertArrayEquals(new String[]{"A7", "A9", "A10", "A5", "BaggageClaim"}, route.getNodes().toArray());
		
		baggageProcessor.activateConveyorBelt("A7", "A8");
		baggageProcessor.removeConveyorBelt("A7", "A9");		
	}

	@Test
	public void testRouteBlockGate() {
		baggageProcessor.addConveyorBelt("A7", "A9", 2);
		
		BaggageInfo baggageInfo = new BaggageInfo();
		baggageInfo.setBagNumber("0005");
		baggageInfo.setEntryPoint("A7");
		baggageInfo.setFlightId("ARRIVAL");
		
		baggageProcessor.blockConveyorBeltFromOrTo("A8");
		BaggageRoute route = baggageProcessor.findRoute(baggageInfo);
		Assert.assertEquals(12, route.getTravelTime());
		Assert.assertArrayEquals(new String[]{"A7", "A9", "A10", "A5", "BaggageClaim"}, route.getNodes().toArray());
		
		baggageProcessor.activateConveyorBeltFromOrTo("A8");
		baggageProcessor.removeConveyorBelt("A7", "A9");		
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testNoConveyerBelt() {
		BaggageProcessor baggageProcessor = new BaggageProcessor("JFK");
		BaggageRoute route = baggageProcessor.findRoute("A1", "A2");
		Assert.fail();
	}
}