package barclays.airport.dao;

import org.junit.Assert;
import org.junit.Test;

@SuppressWarnings("javadoc")
public class TestFlightDao {
	
	@Test
	public void testGetNotExists(){
		Assert.assertNull(FlightDao.getFlightDepartureInfo("InvalidObject"));
	}
	
	@Test
	public void testSaveAndGet(){
		FlightDao.saveFlightDepartureInfo(new DepartureInfo("UA10", "A1"));
		Assert.assertNotNull(FlightDao.getFlightDepartureInfo("UA10"));
	}
	
	@Test
	public void testDeleteGet(){
		DepartureInfo departureInfo = new DepartureInfo("UA10", "A1");
		FlightDao.saveFlightDepartureInfo(departureInfo);
		FlightDao.deleteFlightDepartureInfo(departureInfo);
		Assert.assertNull(FlightDao.getFlightDepartureInfo(departureInfo.getFlightId()));
	}
	
	@Test
	public void testDuplicate(){
		DepartureInfo departureInfo = new DepartureInfo("UA10", "A1");
		FlightDao.saveFlightDepartureInfo(departureInfo);
		FlightDao.saveFlightDepartureInfo(departureInfo);
		FlightDao.saveFlightDepartureInfo(departureInfo);
		FlightDao.saveFlightDepartureInfo(departureInfo);
		Assert.assertEquals(1, FlightDao.getNoOfDepartureInfo());
	}
	
	
	@Test
	public void testRepeatedDelete(){
		DepartureInfo departureInfo = new DepartureInfo("UA10", "A1");
		FlightDao.saveFlightDepartureInfo(departureInfo);
		FlightDao.deleteFlightDepartureInfo(departureInfo);
		FlightDao.deleteFlightDepartureInfo(departureInfo);
		FlightDao.deleteFlightDepartureInfo(departureInfo);
		FlightDao.deleteFlightDepartureInfo(departureInfo);
		FlightDao.deleteFlightDepartureInfo(departureInfo);
		Assert.assertEquals(0, FlightDao.getNoOfDepartureInfo());
	}
}
