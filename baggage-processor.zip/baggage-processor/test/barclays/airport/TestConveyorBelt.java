package barclays.airport;

import org.junit.Assert;
import org.junit.Test;


public class TestConveyorBelt {
	
	@Test(expected=IllegalArgumentException.class)
	public void testValidityEmptyStart(){
		ConveyorBelt belt1 = new ConveyorBelt("", "B", 1);
		Assert.fail();
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testValidityNullStart(){
		ConveyorBelt belt1 = new ConveyorBelt(null, "B", 1);
		Assert.fail();
	}

	@Test(expected=IllegalArgumentException.class)
	public void testValidityEmptyEnd(){
		ConveyorBelt belt2 = new ConveyorBelt("A", "", 1);
		Assert.fail();
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testValidityNullEnd(){
		ConveyorBelt belt2 = new ConveyorBelt("A", null, 1);
		Assert.fail();
	}

	@Test(expected=IllegalArgumentException.class)
	public void testValidityZeroTime(){
		ConveyorBelt belt2 = new ConveyorBelt("A", "B", 0);
		Assert.fail();
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testValidityNegativeTime(){
		ConveyorBelt belt2 = new ConveyorBelt("A", "B", -1);
		Assert.fail();
	}

	@Test
	public void testEqualitySelf(){
		ConveyorBelt belt1 = new ConveyorBelt("A", "B", 1);
		Assert.assertEquals(belt1, belt1);
	}

	@Test
	public void testEqualityMultipleInstanceSameName(){
		ConveyorBelt belt1 = new ConveyorBelt("A", "B", 1);
		ConveyorBelt belt2 = new ConveyorBelt("A", "B", 2);
		Assert.assertEquals(belt1, belt2);
	}
	
	
	@Test
	public void testEqualityReverseName(){
		ConveyorBelt belt1 = new ConveyorBelt("A", "B", 1);
		ConveyorBelt belt2 = new ConveyorBelt("B", "A", 2);
		Assert.assertNotEquals(belt1, belt2);
	}
	
	@Test
	public void testHashCodeSelf(){
		ConveyorBelt belt1 = new ConveyorBelt("A", "B", 1);
		Assert.assertEquals(belt1.hashCode(), belt1.hashCode());
	}

	@Test
	public void testHashCodeMultipleInstanceSameName(){
		ConveyorBelt belt1 = new ConveyorBelt("A", "B", 1);
		ConveyorBelt belt2 = new ConveyorBelt("A", "B", 2);
		Assert.assertEquals(belt1.hashCode(), belt2.hashCode());
	}
	
	
	@Test
	public void testHashCodeReverseName(){
		ConveyorBelt belt1 = new ConveyorBelt("A", "B", 1);
		ConveyorBelt belt2 = new ConveyorBelt("B", "A", 2);
		Assert.assertNotEquals(belt1.hashCode(), belt2.hashCode());
	}

}

