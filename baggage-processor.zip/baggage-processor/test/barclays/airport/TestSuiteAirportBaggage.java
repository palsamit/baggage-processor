package barclays.airport;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import barclays.airport.dao.TestFlightDao;

@SuppressWarnings("javadoc")
@RunWith(Suite.class)
@Suite.SuiteClasses({
	TestFlightDao.class,
	TestConveyorBelt.class,
	TestBaggageProcessor.class
})
public class TestSuiteAirportBaggage {

}
